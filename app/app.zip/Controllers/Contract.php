<?php

namespace App\Controllers;

class Contract extends Security_Controller {

    function __construct() {
        parent::__construct(false);
    }

    function index() {
        app_redirect("forbidden");
    }

    function preview($contract_id = 0, $public_key = "") {
        if (!($contract_id && $public_key)) {
            show_404();
        }

        validate_numeric_value($contract_id);

        //check public key
        $contract_info = $this->Contracts_model->get_one($contract_id);
        if ($contract_info->public_key !== $public_key) {
            show_404();
        }

        $view_data = array();

        $contract_data = get_contract_making_data($contract_id);
        if (!$contract_data) {
            show_404();
        }

        $view_data['contract_preview'] = prepare_contract_view($contract_data);
        $view_data['show_close_preview'] = false; //don't show back button
        $view_data['contract_id'] = $contract_id;
        $view_data['contract_type'] = "public";
        $view_data['public_key'] = clean_data($public_key);

        return view("contracts/contract_public_preview", $view_data);
    }

    //update contract status
    function update_contract_status($contract_id, $public_key, $status) {
        validate_numeric_value($contract_id);
        if (!($contract_id && $public_key && $status)) {
            show_404();
        }

        $contract_info = $this->Contracts_model->get_one($contract_id);
        if (!($contract_info->id && $contract_info->public_key === $public_key)) {
            show_404();
        }

        //client can only update the status once and the value should be either accepted or declined
        if ($status == "accepted" || $status == "declined") {
            $contract_data = array("status" => $status);
            $contract_id = $this->Contracts_model->ci_save($contract_data, $contract_id);

            //create notification
            if ($status == "accepted") {
                log_notification("contract_accepted", array("contract_id" => $contract_id), isset($this->login_user->id) ? $this->login_user->id : "0");
                $this->session->setFlashdata("success_message", app_lang("contract_accepted"));
            } else if ($status == "declined") {
                log_notification("contract_rejected", array("contract_id" => $contract_id), isset($this->login_user->id) ? $this->login_user->id : "0");
                $this->session->setFlashdata("error_message", app_lang('contract_rejected'));
            }
        }
    }

    //print contract
    function print_contract($contract_id = 0, $public_key = "") {
        validate_numeric_value($contract_id);
        if ($contract_id && $public_key) {
            $view_data = get_contract_making_data($contract_id);

            //check public key
            $contract_info = get_array_value($view_data, "contract_info");
            if ($contract_info->public_key !== $public_key) {
                show_404();
            }

            $view_data['contract_preview'] = prepare_contract_view($view_data);

            echo json_encode(array("success" => true, "print_view" => $this->template->view("contracts/print_contract", $view_data)));
        } else {
            echo json_encode(array("success" => false, app_lang('error_occurred')));
        }
    }

    function accept_contract_modal_form($contract_id = 0, $public_key = "") {
        validate_numeric_value($contract_id);
        if (!$contract_id) {
            show_404();
        }

        $contract_info = $this->Contracts_model->get_one($contract_id);
        if (!$contract_info->id) {
            show_404();
        }

        if ($public_key) {
            //public contract
            if ($contract_info->public_key !== $public_key) {
                show_404();
            }

            $view_data["show_info_fields"] = true;
        } else {
            //contract preview, should be logged in client contact
            $this->init_permission_checker("contract");
            $this->access_only_allowed_members_or_client_contact($contract_info->client_id);
            if ($this->login_user->user_type === "client" && $this->login_user->client_id !== $contract_info->client_id) {
                show_404();
            }

            $view_data["show_info_fields"] = false;
        }

        $view_data["model_info"] = $contract_info;
        return $this->template->view('contracts/accept_contract_modal_form', $view_data);
    }

    function accept_contract() {
        $validation_array = array(
            "id" => "numeric|required",
            "public_key" => "required"
        );

        if (get_setting("add_signature_option_on_accepting_contract")) {
            $validation_array["signature"] = "required";
        }

        $this->validate_submitted_data($validation_array);

        $contract_id = $this->request->getPost("id");
        $contract_info = $this->Contracts_model->get_one($contract_id);
        if (!$contract_info->id) {
            show_404();
        }

        $public_key = $this->request->getPost("public_key");
        if ($contract_info->public_key !== $public_key) {
            show_404();
        }

        $name = $this->request->getPost("name");
        $email = $this->request->getPost("email");
        $signature = $this->request->getPost("signature");

        $meta_data = array();
        $contract_data = array();

        if ($signature) {
            $signature = explode(",", $signature);
            $signature = get_array_value($signature, 1);
            $signature = base64_decode($signature);
            $signature = serialize(move_temp_file("signature.jpg", get_setting("timeline_file_path"), "contract", NULL, "", $signature));

            $meta_data["signature"] = $signature;
            $meta_data["signed_date"] = get_current_utc_time();
        }

        if ($name) {
            //from public contract
            if (!$email) {
                show_404();
            }

            $meta_data["name"] = $name;
            $meta_data["email"] = $email;
        } else {
            //from preview, should be logged in client contact
            $this->init_permission_checker("contract");
            $this->access_only_allowed_members_or_client_contact($contract_info->client_id);
            if ($this->login_user->user_type === "client" && $this->login_user->client_id !== $contract_info->client_id) {
                show_404();
            }

            $contract_data["accepted_by"] = $this->login_user->id;
        }

        $contract_data["meta_data"] = serialize($meta_data);
        $contract_data["status"] = "accepted";

        if ($this->Contracts_model->ci_save($contract_data, $contract_id)) {
            log_notification("contract_accepted", array("contract_id" => $contract_id), ($name ? "0" : $this->login_user->id));
            echo json_encode(array("success" => true, "message" => app_lang("contract_accepted")));
        } else {
            echo json_encode(array("success" => false, "message" => app_lang("error_occurred")));
        }
    }

}

/* End of file Contract.php */
/* Location: ./app/controllers/Contract.php */