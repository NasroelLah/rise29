<div id="clock-status-widget" class="box border-top bg-white">
    <div class="box-content border-end">
        <div class="card-body ">
            <h1><?php echo $members_clocked_in; ?></h1>
            <span class="text-off uppercase"><?php echo app_lang("members_clocked_in"); ?></span>

        </div>
    </div>
    <div class="box-content">
        <div class="card-body ">
            <h1 class=""><?php echo $members_clocked_out; ?></h1>
            <span class="text-off uppercase"><?php echo app_lang("members_clocked_out"); ?></span>
        </div>
    </div>
</div>